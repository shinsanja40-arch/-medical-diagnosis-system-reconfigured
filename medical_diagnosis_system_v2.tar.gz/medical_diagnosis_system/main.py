#!/usr/bin/env python3
"""
Main entry point for the Medical Diagnosis System
"""

from medical_diagnosis_system import main

if __name__ == "__main__":
    main()
