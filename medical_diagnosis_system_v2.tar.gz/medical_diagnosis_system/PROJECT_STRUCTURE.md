# Project Structure

```
medical-diagnosis-system/
│
├── README.md                          # 프로젝트 개요 및 설치 가이드
├── LICENSE                            # MIT 라이선스
├── CONTRIBUTING.md                    # 기여 가이드라인
├── requirements.txt                   # Python 의존성
├── setup.py                          # 패키지 설치 스크립트
├── .env.example                      # 환경 변수 템플릿
├── .gitignore                        # Git 제외 파일
├── config.yaml                       # 시스템 설정
│
├── main.py                           # 메인 실행 파일
├── medical_diagnosis_system.py       # 핵심 시스템 구현
├── examples.py                       # 사용 예제
├── test_system.py                    # 테스트 스위트
│
└── docs/                             # 문서
    ├── ARCHITECTURE.md               # 시스템 아키텍처 설명
    ├── USAGE.md                      # 사용 가이드
    └── PAPER_TEMPLATE.md             # 논문 템플릿
```

## File Descriptions

### Core Files

- **main.py**: 프로그램 진입점
- **medical_diagnosis_system.py**: 전체 시스템 구현
  - MedicalDiagnosisSystem 클래스
  - PatientInfo, DiagnosisOpinion 데이터 클래스
  - 5단계 토론 프로토콜
  - 심판 개입 로직

### Configuration

- **config.yaml**: 시스템 파라미터 설정
  - 최대 라운드, 교착 임계값
  - API 설정
  - 출력 형식
  - 안전 설정

- **.env.example**: 환경 변수 템플릿
  - ANTHROPIC_API_KEY 설정

### Documentation

- **README.md**: 프로젝트 소개 및 빠른 시작
- **CONTRIBUTING.md**: 기여 방법
- **docs/ARCHITECTURE.md**: 상세 아키텍처
- **docs/USAGE.md**: 사용 가이드
- **docs/PAPER_TEMPLATE.md**: 연구 논문 템플릿

### Testing & Examples

- **test_system.py**: Unit 및 Integration 테스트
- **examples.py**: 다양한 사용 예제

### Package Management

- **requirements.txt**: pip 의존성
- **setup.py**: 패키지 설치 설정
- **LICENSE**: MIT 라이선스 전문

## Quick Start

1. **설치**
   ```bash
   git clone https://github.com/yourusername/medical-diagnosis-system.git
   cd medical-diagnosis-system
   pip install -r requirements.txt
   ```

2. **설정**
   ```bash
   cp .env.example .env
   # .env 파일에 API 키 입력
   ```

3. **실행**
   ```bash
   python main.py
   ```

4. **테스트**
   ```bash
   python test_system.py
   ```

## Development Workflow

1. Fork repository
2. Create feature branch
3. Make changes
4. Run tests
5. Submit pull request

## For Researchers

논문 작성을 위해 다음 파일들을 참고하세요:

- **docs/PAPER_TEMPLATE.md**: 논문 구조 및 템플릿
- **docs/ARCHITECTURE.md**: 시스템 설계 상세
- **examples.py**: 실험 코드 예제
- **test_system.py**: 평가 메트릭 구현
