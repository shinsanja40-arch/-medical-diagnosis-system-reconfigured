#!/usr/bin/env python3
"""
고급 기능 예제: 이미지 분석 및 웹 검색
Example: Advanced Features - Image Analysis and Web Search
"""

import os
from medical_diagnosis_system import MedicalDiagnosisSystem, PatientInfo


def example_with_image_and_search():
    """
    이미지 업로드 및 웹 검색 기능을 포함한 진단 예제
    Example with image upload and web search
    """
    print("=" * 70)
    print("예제: 이미지 분석 및 웹 검색")
    print("Example: Image Analysis and Web Search")
    print("=" * 70)
    print()
    
    # Initialize system
    api_key = os.getenv("ANTHROPIC_API_KEY")
    if not api_key:
        print("Error: ANTHROPIC_API_KEY 환경 변수가 설정되지 않았습니다.")
        return
    
    system = MedicalDiagnosisSystem(api_key=api_key)
    
    # Enable features
    system.enable_web_search = True
    system.enable_image_analysis = True
    system.language = "ko"
    
    print("✓ 웹 검색 활성화")
    print("✓ 이미지 분석 활성화")
    print()
    
    # Example 1: Skin condition with image
    print("시나리오 1: 피부 병변 사진을 포함한 진단")
    print("-" * 70)
    
    # Set patient info
    system.patient_info = PatientInfo(
        age=45,
        gender="여성",
        symptoms=["피부 발진", "가려움증"],
        chronic_conditions=[]
    )
    
    # Add image (if exists)
    image_path = input("피부 사진 경로를 입력하세요 (없으면 Enter): ").strip()
    if image_path and os.path.exists(image_path):
        system.add_medical_image(image_path, "피부 병변")
        print()
    
    system.inquiry_complete = True
    
    # Run diagnosis with web search
    print("진단을 시작합니다...")
    print("(웹 검색을 통해 최신 피부과 정보를 조회합니다)")
    print()
    
    system._start_diagnosis_debate()
    
    print("\n" + "=" * 70)
    print("진단 완료!")
    print("=" * 70)


def example_chest_xray_analysis():
    """
    흉부 X-ray 분석 예제
    Chest X-ray analysis example
    """
    print("=" * 70)
    print("예제: 흉부 X-ray 영상 분석")
    print("Example: Chest X-ray Image Analysis")
    print("=" * 70)
    print()
    
    api_key = os.getenv("ANTHROPIC_API_KEY")
    if not api_key:
        print("Error: ANTHROPIC_API_KEY 환경 변수가 설정되지 않았습니다.")
        return
    
    system = MedicalDiagnosisSystem(api_key=api_key)
    system.enable_web_search = True
    system.enable_image_analysis = True
    
    # Set patient info
    system.patient_info = PatientInfo(
        age=62,
        gender="남성",
        symptoms=["기침", "호흡곤란", "흉통"],
        chronic_conditions=["고혈압"],
        medications=["암로디핀"]
    )
    
    # Add X-ray image
    xray_path = input("흉부 X-ray 이미지 경로 (없으면 Enter): ").strip()
    if xray_path and os.path.exists(xray_path):
        system.add_medical_image(xray_path, "흉부 X-ray")
        print()
    
    system.inquiry_complete = True
    
    print("영상의학과와 호흡기내과 전문의가 협진을 시작합니다...")
    print()
    
    system._start_diagnosis_debate()


def example_multilingual():
    """
    영어 모드 예제
    English mode example
    """
    print("=" * 70)
    print("Example: English Language Mode")
    print("=" * 70)
    print()
    
    api_key = os.getenv("ANTHROPIC_API_KEY")
    if not api_key:
        print("Error: ANTHROPIC_API_KEY environment variable not set.")
        return
    
    system = MedicalDiagnosisSystem(api_key=api_key)
    system.enable_web_search = True
    system.language = "en"
    
    print("✓ Language set to English")
    print("✓ Web search enabled")
    print()
    
    # Set patient info in English
    system.patient_info = PatientInfo(
        age=28,
        gender="Female",
        symptoms=["headache", "nausea", "dizziness"],
        chronic_conditions=[]
    )
    
    system.inquiry_complete = True
    
    print("Starting diagnosis...")
    print("(The system will search for latest medical research)")
    print()
    
    system._start_diagnosis_debate()


def example_rare_disease_search():
    """
    희귀 질환 웹 검색 예제
    Rare disease web search example
    """
    print("=" * 70)
    print("예제: 희귀 질환 진단 (웹 검색 활용)")
    print("Example: Rare Disease Diagnosis with Web Search")
    print("=" * 70)
    print()
    
    api_key = os.getenv("ANTHROPIC_API_KEY")
    if not api_key:
        print("Error: ANTHROPIC_API_KEY 환경 변수가 설정되지 않았습니다.")
        return
    
    system = MedicalDiagnosisSystem(api_key=api_key)
    system.enable_web_search = True
    
    # Complex symptoms suggesting rare condition
    system.patient_info = PatientInfo(
        age=35,
        gender="여성",
        symptoms=[
            "근육 약화",
            "피로",
            "안검하수",
            "복시",
            "연하곤란"
        ],
        chronic_conditions=[]
    )
    
    system.inquiry_complete = True
    
    print("복잡한 증상에 대한 진단을 시작합니다.")
    print("전문의들이 웹 검색을 통해 희귀 질환 정보를 조회합니다.")
    print()
    
    system._start_diagnosis_debate()


if __name__ == "__main__":
    print("\n고급 기능 예제 - Advanced Features Examples\n")
    print("사용 가능한 예제:")
    print("  1. 피부 병변 이미지 분석")
    print("  2. 흉부 X-ray 분석")
    print("  3. 영어 모드 (English)")
    print("  4. 희귀 질환 진단 (웹 검색)")
    print()
    
    choice = input("실행할 예제 번호 (1-4): ").strip()
    print()
    
    if choice == "1":
        example_with_image_and_search()
    elif choice == "2":
        example_chest_xray_analysis()
    elif choice == "3":
        example_multilingual()
    elif choice == "4":
        example_rare_disease_search()
    else:
        print("잘못된 선택입니다.")
